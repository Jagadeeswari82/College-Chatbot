import json
import requests


# -----------------------------------
# Load test questions
# -----------------------------------

with open("test_questions.json", "r", encoding="utf-8") as file:
    questions = json.load(file)


# -----------------------------------
# Chatbot API
# -----------------------------------

CHATBOT_URL = "http://127.0.0.1:5000/chat"


# -----------------------------------
# Evaluation variables
# -----------------------------------

correct = 0
partial = 0
incorrect = 0


# -----------------------------------
# Run evaluation
# -----------------------------------

for item in questions:

    question_id = item["id"]
    question = item["question"]
    expected_topic = item["expected_topic"]

    print("\n" + "=" * 60)
    print(f"Test {question_id}")
    print("Question:", question)
    print("Expected topic:", expected_topic)

    try:

        response = requests.post(
            CHATBOT_URL,
            json={
                "message": question,
                "history": []
            }
        )

        if response.status_code == 200:

            result = response.json()
            answer = result.get("answer", "")

            print("Chatbot Answer:")
            print(answer)

            # -----------------------------------
            # Simple keyword-based evaluation
            # -----------------------------------

            answer_lower = answer.lower()

            keywords = expected_topic.lower().split()

            matched = 0

            for keyword in keywords:
                if keyword in answer_lower:
                    matched += 1

            # Determine result

            if matched == len(keywords):
                result_status = "CORRECT"
                correct += 1

            elif matched > 0:
                result_status = "PARTIALLY CORRECT"
                partial += 1

            else:
                result_status = "INCORRECT"
                incorrect += 1

            print("Evaluation:", result_status)

        else:

            print("API Error:", response.status_code)
            incorrect += 1

    except Exception as e:

        print("Connection Error:", e)
        incorrect += 1


# -----------------------------------
# Calculate accuracy
# -----------------------------------

total = len(questions)

accuracy = (correct / total) * 100


# -----------------------------------
# Final evaluation report
# -----------------------------------

print("\n")
print("=" * 60)
print("FINAL CHATBOT EVALUATION")
print("=" * 60)

print("Total Questions :", total)
print("Correct          :", correct)
print("Partially Correct:", partial)
print("Incorrect        :", incorrect)
print(f"Accuracy         : {accuracy:.2f}%")

print("=" * 60)