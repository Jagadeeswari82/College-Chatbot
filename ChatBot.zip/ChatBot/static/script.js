// ============================================================
// GET HTML ELEMENTS
// ============================================================

const chatBox = document.getElementById("chat-box");

const messageInput =
    document.getElementById("message-input");

const sendButton =
    document.getElementById("send-button");

const typing =
    document.getElementById("typing");


// ============================================================
// CONVERSATION MEMORY
// ============================================================

// This array stores all questions and answers
// during the current browser session.
//
// Example:
//
// [
//     {
//         role: "user",
//         content: "What is the hostel fee?"
//     },
//     {
//         role: "assistant",
//         content: "The hostel fee is ₹75,000 per year."
//     }
// ]

let conversationHistory = [];


// ============================================================
// SEND MESSAGE
// ============================================================

async function sendMessage() {

    // Get student's question
    const message =
        messageInput.value.trim();


    // --------------------------------------------------------
    // DON'T SEND EMPTY MESSAGE
    // --------------------------------------------------------

    if (message === "") {
        return;
    }


    // --------------------------------------------------------
    // DISPLAY STUDENT MESSAGE
    // --------------------------------------------------------

    addMessage(
        message,
        "user"
    );


    // Clear input box
    messageInput.value = "";


    // --------------------------------------------------------
    // SHOW TYPING INDICATOR
    // --------------------------------------------------------

    if (typing) {
        typing.classList.remove("hidden");
    }


    // Disable send button while AI is responding
    sendButton.disabled = true;


    try {

        // ----------------------------------------------------
        // SEND QUESTION + PREVIOUS HISTORY TO FLASK
        // ----------------------------------------------------

        const response = await fetch(
            "/chat",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({

                    // Current question
                    message: message,

                    // Previous questions and answers
                    history: conversationHistory

                })
            }
        );


        // Convert Flask response to JSON
        const data =
            await response.json();


        // ----------------------------------------------------
        // HIDE TYPING INDICATOR
        // ----------------------------------------------------

        if (typing) {
            typing.classList.add("hidden");
        }


        // Enable send button
        sendButton.disabled = false;


        // ----------------------------------------------------
        // CHECK FOR ERROR
        // ----------------------------------------------------

        if (data.error) {

            addMessage(
                data.error,
                "bot"
            );

            return;
        }


        // ----------------------------------------------------
        // GET AI ANSWER
        // ----------------------------------------------------

        const answer =
            data.answer;


        // Display AI answer
        addMessage(
            answer,
            "bot"
        );


        // ----------------------------------------------------
        // SAVE CURRENT QUESTION
        // ----------------------------------------------------

        conversationHistory.push({

            role: "user",

            content: message

        });


        // ----------------------------------------------------
        // SAVE AI ANSWER
        // ----------------------------------------------------

        conversationHistory.push({

            role: "assistant",

            content: answer

        });


        // ----------------------------------------------------
        // NOW THE BOT REMEMBERS THIS CONVERSATION
        // ----------------------------------------------------

        console.log(
            "Conversation memory:",
            conversationHistory
        );


    } catch (error) {

        console.error(
            "Chat error:",
            error
        );


        // Hide typing indicator
        if (typing) {
            typing.classList.add("hidden");
        }


        // Enable send button
        sendButton.disabled = false;


        // Show error
        addMessage(
            "Sorry, something went wrong. Please try again.",
            "bot"
        );
    }
}


// ============================================================
// ADD MESSAGE TO CHAT
// ============================================================

function addMessage(text, sender) {

    // Create message container
    const messageDiv =
        document.createElement("div");


    messageDiv.classList.add(
        "message"
    );


    // --------------------------------------------------------
    // USER OR BOT CLASS
    // --------------------------------------------------------

    if (sender === "user") {

        messageDiv.classList.add(
            "user-message"
        );

    } else {

        messageDiv.classList.add(
            "bot-message"
        );
    }


    // --------------------------------------------------------
    // AVATAR
    // --------------------------------------------------------

    const avatar =
        document.createElement("div");


    avatar.classList.add(
        "avatar"
    );


    if (sender === "user") {

        avatar.textContent = "👤";

    } else {

        avatar.textContent = "🤖";
    }


    // --------------------------------------------------------
    // MESSAGE CONTENT
    // --------------------------------------------------------

    const content =
        document.createElement("div");


    content.classList.add(
        "message-content"
    );


    // --------------------------------------------------------
    // NAME
    // --------------------------------------------------------

    const name =
        document.createElement("strong");


    if (sender === "user") {

        name.textContent = "You";

    } else {

        name.textContent = "GVIT Assistant";
    }


    // --------------------------------------------------------
    // MESSAGE TEXT
    // --------------------------------------------------------

    const paragraph =
        document.createElement("p");


    paragraph.textContent = text;


    // --------------------------------------------------------
    // BUILD MESSAGE
    // --------------------------------------------------------

    content.appendChild(name);

    content.appendChild(paragraph);

    messageDiv.appendChild(avatar);

    messageDiv.appendChild(content);


    // --------------------------------------------------------
    // ADD MESSAGE TO CHAT BOX
    // --------------------------------------------------------

    chatBox.appendChild(
        messageDiv
    );


    // --------------------------------------------------------
    // SCROLL TO LATEST MESSAGE
    // --------------------------------------------------------

    chatBox.scrollTop =
        chatBox.scrollHeight;
}


// ============================================================
// QUICK QUESTION BUTTONS
// ============================================================

function askQuestion(question) {

    messageInput.value =
        question;

    sendMessage();
}


// ============================================================
// SEND BUTTON
// ============================================================

sendButton.addEventListener(
    "click",
    sendMessage
);


// ============================================================
// ENTER KEY
// ============================================================

messageInput.addEventListener(
    "keydown",
    function(event) {

        if (event.key === "Enter") {

            event.preventDefault();

            sendMessage();
        }
    }
);