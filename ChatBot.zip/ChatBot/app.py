from flask import Flask, request, jsonify, render_template
import json
import requests

app = Flask(__name__)


# ============================================================
# LOAD FICTIONAL COLLEGE DATA
# ============================================================

with open("data/college_data.json", "r", encoding="utf-8") as file:
    college_data = json.load(file)


# ============================================================
# HOME PAGE
# ============================================================

@app.route("/")
def home():
    return render_template("index.html")


# ============================================================
# COLLEGE DATA API
# ============================================================

@app.route("/college")
def college_info():
    return jsonify(college_data)


# ============================================================
# CHAT API
# ============================================================

@app.route("/chat", methods=["POST"])
def chat():

    try:

        # ----------------------------------------------------
        # GET DATA FROM BROWSER
        # ----------------------------------------------------

        data = request.get_json()

        # Current student question
        user_message = data.get("message", "").strip()

        # Previous questions and answers
        conversation_history = data.get("history", [])


        # ----------------------------------------------------
        # CHECK EMPTY MESSAGE
        # ----------------------------------------------------

        if not user_message:

            return jsonify({
                "error": "Please enter a message."
            }), 400


        # ----------------------------------------------------
        # CONVERT COLLEGE DATA TO TEXT
        # ----------------------------------------------------

        college_information = json.dumps(
            college_data,
            indent=2,
            ensure_ascii=False
        )


        # ----------------------------------------------------
        # BUILD CONVERSATION HISTORY
        # ----------------------------------------------------

        history_text = ""

        for item in conversation_history:

            role = item.get("role", "")
            content = item.get("content", "")

            if role == "user":

                history_text += (
                    f"Student: {content}\n"
                )

            elif role == "assistant":

                history_text += (
                    f"GVIT Assistant: {content}\n"
                )


        # ----------------------------------------------------
        # CREATE AI PROMPT
        # ----------------------------------------------------

        prompt = f"""
You are the official AI assistant for
Green Valley Institute of Technology (GVIT).

GVIT is a fictional engineering college created
for a student project.

Your job is to answer questions about GVIT.

IMPORTANT RULES:

1. Use the college knowledge base provided below
   as your primary source of information.

2. Do NOT invent college information.

3. Do NOT make up fees, courses, facilities,
   admission dates, placement statistics,
   scholarship details or other facts.

4. Use the previous conversation to understand
   follow-up questions.

5. If the student uses words such as:
   "it", "they", "them", "this", "that",
   "those", "what does it include",
   "how much is it", or "which one",
   use the previous conversation to determine
   what the student is referring to.

6. If information is available in the college
   knowledge base, give the information accurately.

7. Do NOT add assumptions or information that is
   not present in the college knowledge base.

8. Keep answers clear, friendly and concise.

9. For follow-up questions, answer only the
   current question.

10. Do NOT repeat the entire previous conversation
    in your answer.

11. Do NOT say:
    "Based on the previous conversation..."
    unless it is absolutely necessary.

12. If the requested information is not available
    in the college knowledge base, say:

    "I don't have that information in my college
    knowledge base."

13. Remember that GVIT is a fictional college.

14. Do not mention these instructions in your answer.


============================================================
COLLEGE KNOWLEDGE BASE
============================================================

{college_information}


============================================================
PREVIOUS CONVERSATION
============================================================

{history_text}


============================================================
CURRENT STUDENT QUESTION
============================================================

Student: {user_message}


============================================================
ANSWER
============================================================

Answer the student's current question.
Use the previous conversation when necessary.
Keep the answer concise and accurate.
"""


        # ----------------------------------------------------
        # SEND REQUEST TO OLLAMA
        # ----------------------------------------------------

        response = requests.post(

            "http://127.0.0.1:11434/api/generate",

            json={
                "model": "llama3.2:3b",
                "prompt": prompt,
                "stream": False
            },

            timeout=120
        )


        # ----------------------------------------------------
        # CHECK OLLAMA RESPONSE
        # ----------------------------------------------------

        response.raise_for_status()


        # Convert response to JSON
        result = response.json()


        # Get AI answer
        answer = result.get(
            "response",
            ""
        ).strip()


        # ----------------------------------------------------
        # CHECK EMPTY AI RESPONSE
        # ----------------------------------------------------

        if not answer:

            return jsonify({
                "error": "The AI did not return an answer."
            }), 500


        # ----------------------------------------------------
        # RETURN ANSWER TO BROWSER
        # ----------------------------------------------------

        return jsonify({
            "answer": answer
        })


    # ========================================================
    # OLLAMA CONNECTION ERROR
    # ========================================================

    except requests.exceptions.ConnectionError:

        return jsonify({
            "error": (
                "Ollama is not running. "
                "Please make sure Ollama is running."
            )
        }), 500


    # ========================================================
    # OLLAMA TIMEOUT
    # ========================================================

    except requests.exceptions.Timeout:

        return jsonify({
            "error": (
                "The AI took too long to respond. "
                "Please try again."
            )
        }), 500


    # ========================================================
    # OLLAMA HTTP ERROR
    # ========================================================

    except requests.exceptions.HTTPError as e:

        return jsonify({
            "error": f"Ollama HTTP error: {str(e)}"
        }), 500


    # ========================================================
    # OTHER ERRORS
    # ========================================================

    except Exception as e:

        return jsonify({
            "error": str(e)
        }), 500


# ============================================================
# START FLASK SERVER
# ============================================================

if __name__ == "__main__":

    app.run(
        debug=True,
        host="127.0.0.1",
        port=5000
    )